# 1.1.0

Added config option making only corrupted pets immortal.

# 1.0.0

Initial Release
